<?php
session_start();
$con = mysqli_connect("localhost","root","","policeprojectdb");


if(isset($_POST['insert_data']))
{
    $Name=mysqli_real_escape_string($con,$_POST['Name']);
    $NRPC=mysqli_real_escape_string($con,$_POST['NRPC']);
    $Gender=mysqli_real_escape_string($con,$_POST['gender']);
    $Native=mysqli_real_escape_string($con,$_POST['Native']);
    $DOB=mysqli_real_escape_string($con,$_POST['DOB']);
}
