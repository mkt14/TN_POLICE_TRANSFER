<!DOCTYPE html>
<html>
<head>
    <title>SQL Query Results</title>
</head>
<body>
    <h1>SQL Query Results</h1>

    <?php
    // Retrieve the name value from the form
    $name = $_POST['name'];

    // Create a database connection
    $conn = new mysqli('localhost', 'username', 'password', 'database_name');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Construct the SQL query
    $sql = "SELECT * FROM your_table WHERE name = '$name'";

    // Execute the query
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output the results
        while ($row = $result->fetch_assoc()) {
            echo "ID: " . $row['id'] . "<br>";
            echo "Name: " . $row['name'] . "<br>";
            echo "Email: " . $row['email'] . "<br>";
            echo "<br>";
        }
    } else {
        echo "No results found.";
    }

    // Close the database connection
    $conn->close();
    ?>

    <br>
    <a href="index.html">Back to Form</a>
</body>
</html>
