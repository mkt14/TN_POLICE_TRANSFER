<?php
session_start();
$con = mysqli_connect("localhost","root","","policeprojectdb");


if(isset($_POST['insert_data']))
{
    $dg=$_POST['dg'];
    // $dg =  mysqli_real_escape_string($con, $_POST['dg']);
    $Name = mysqli_real_escape_string($con, $_POST['Name']);
    $Employee_ID = mysqli_real_escape_string($con, $_POST['Employee_ID']);
    $DOE = mysqli_real_escape_string($con, $_POST['DOE']);
    $DOJCB = mysqli_real_escape_string($con, $_POST['DOJCB']);
    $Native_District = mysqli_real_escape_string($con, $_POST['Native_District']);
    $DOP=mysqli_real_escape_string($con, $_POST['DOP']);
    $DOB=mysqli_real_escape_string($con, $_POST['DOB']);
    $Cbatallion=mysqli_escape_string($con,$_POST['Cbatallion']);
    $PRSMarks = mysqli_real_escape_string($con, $_POST['PRSMarks']);
    $reason=mysqli_real_escape_string($con,$_POST['reason']);
    $p1 = mysqli_real_escape_string($con, $_POST['p1']);
    $p2 = mysqli_real_escape_string($con, $_POST['p2']);
    $PRDetail=mysqli_real_escape_string($con,$_POST['PRDetail']);

    // $ROT = mysqli_real_escape_string($con, $_POST['ROT']);
    $oyc = mysqli_real_escape_string($con, $_POST['oyc']);

    if($dg==1){
    
    $query = "INSERT INTO hav_grtmt (Name,Employee_ID,DOE,DOJCB,Native_District,PRSMark,p1,p2,ROT,oyc) VALUES ('$Name','$Employee_ID','$DOE','$DOJCB','$Native_District','$PRSMarks','$p1','$p2','$ROT','$oyc') ";
    $query_run = mysqli_query($con, $query);
    }else if($dg==2){
        $query = "INSERT INTO naik_grtmt (Name,Employee_ID,DOE,DOJCB,Native_District,PRSMark,p1,p2,ROT,oyc) VALUES ('$Name','$Employee_ID','$DOE','$DOJCB','$Native_District','$PRSMarks','$p1','$p2','$ROT','$oyc') ";
        $query_run = mysqli_query($con, $query);
    }
    else if($dg=3){
        $query = "INSERT INTO pcmt (Name,Employee_ID,DOE,DOJCB,Native_District,PRSMark,p1,p2,ROT,oyc) VALUES ('$Name','$Employee_ID','$DOE','$DOJCB','$Native_District','$PRSMarks','$p1','$p2','$ROT','$oyc') ";
        $query_run = mysqli_query($con, $query);
    }
    else if($dg=4){
        $query = "INSERT INTO pcvii (Name,Employee_ID,DOE,DOJCB,Native_District,PRSMark,p1,p2,ROT,oyc) VALUES ('$Name','$Employee_ID','$DOE','$DOJCB','$Native_District','$PRSMarks','$p1','$p2','$ROT','$oyc') ";
        $query_run = mysqli_query($con, $query);
    }
   

    
}

?>