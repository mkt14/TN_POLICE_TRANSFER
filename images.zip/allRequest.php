<!DOCTYPE html>
<html>
<head>
    <title>Check all the requests</title>
</head>
<body>
    <h1>SQL Query Form</h1>

    <form method="POST" action="getAllquery.php">
    <label><b>DESIGNATION</b></label><br>
                            <select id="dg" name="dg">
                                <option value="1">HAV (G RT MT)</option>
                                <!-- <option value="">HAV (TSP VIII BN) (G RT MT)</option> -->
                                <option value="2">NAIK (G RT MT)</option>
                                <!-- <option value="">NAIK ( TSP VIII BN) (G RT MT)</option> -->
                                <!-- <option value="">PC VIII</option> -->
                                <!-- <option value="">PC RT</option> -->
                                <!-- <option value="">PC RT (TSP VIII BN)</option> -->
                                <option value="3">PC MT</option>
                                <option value="4">PC MT (TSP VII BN)</option>
                              </select>
        <input type="submit" value="Run Query">
    </form>
</body>
</html>
